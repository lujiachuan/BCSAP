"""受控设备 PV 映射配置的加载、校验与持久化。

背景：PV 名原先写死在三个地方（执行服务的 pv_health、设置页示例表、调束页参数表），
改现场 PV 要改代码。本模块把「业务信号 → PV」变成**唯一配置源**：

* 由执行服务持有并校验（架构文档 6.2：启动时完整校验）；
* 客户端通过 ``/control/v1/pv-mapping`` 读写，不直接碰文件；
* 落盘为 JSON，位置可用 ``SPECTRUM_PV_MAPPING`` 覆盖（默认用户配置目录）。

安全边界：允许配置任意 PV 是现场接入的硬需求。设备访问统一走真实 Channel Access，
落库/写入仍受「只读判定 + 业务参数边界」约束，见 README 的说明。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
from pathlib import Path

from packages.contracts import (
    PvMappingConfig,
    PvMappingEntry,
    PvMappingIssue,
)
from packages.contracts.pv_mapping import SIGNAL_ROLES

from . import device_profiles

CONFIG_VERSION = 1

# 业务信号键：小写点分，供执行服务内部引用，落库、日志、审计都用它。
_SIGNAL_PATTERN = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$")
# EPICS PV 名：允许字母数字与 : . - _ [ ] $ + < >，禁止空白与空串。
_PV_PATTERN = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_:.\-\[\]$+<>]*$")

# 历史默认映射（简明束线 BL:*）：保留供回退与对照，已不再是默认设备。
# 真正的默认设备是团簇离子源与磁电双聚焦，清单见 device_profiles.py。
LEGACY_ENTRIES: tuple[PvMappingEntry, ...] = (
    PvMappingEntry(
        signal="quadrupole.q1.current",
        label="Q1 电流",
        pv="BL:Q1:ISET",
        unit="A",
        writable=True,
        required=True,
    ),
    PvMappingEntry(
        signal="quadrupole.q2.current",
        label="Q2 电流",
        pv="BL:Q2:ISET",
        unit="A",
        writable=True,
        required=True,
    ),
    PvMappingEntry(
        signal="einzel.voltage",
        label="Einzel 电压",
        pv="BL:EL:VSET",
        unit="kV",
        writable=True,
        required=True,
    ),
    PvMappingEntry(
        signal="steerer.x",
        label="X 偏转",
        pv="BL:STEER:X",
        unit="V",
        writable=True,
        required=True,
    ),
    PvMappingEntry(
        signal="steerer.y",
        label="Y 偏转",
        pv="BL:STEER:Y",
        unit="V",
        writable=True,
        required=True,
    ),
    PvMappingEntry(
        signal="source.voltage",
        label="Source 电压",
        pv="BL:SRC:VSET",
        unit="kV",
        writable=True,
        required=False,
    ),
    PvMappingEntry(
        signal="detector.current",
        label="探测器电流",
        pv="BL:DET:CURRENT",
        unit="uA",
        writable=False,
        required=True,
    ),
)

# 模拟网关的初值：仅开发/演示用，真实接入时不参与任何判定。
DEFAULT_SIMULATED_VALUES: dict[str, float] = {
    "quadrupole.q1.current": 1.842,
    "quadrupole.q2.current": -0.625,
    "einzel.voltage": 3.20,
    "steerer.x": 0.08,
    "steerer.y": -0.12,
    "source.voltage": 12.4,
    "detector.current": 8.31,
}


def default_config() -> PvMappingConfig:
    """默认设备配置：团簇离子源与磁电双聚焦（清单见 ``device_profiles``）。"""
    return device_profiles.default_config()


def config_path() -> Path:
    """配置文件位置，可用 ``SPECTRUM_PV_MAPPING`` 覆盖。"""
    override = os.environ.get("SPECTRUM_PV_MAPPING")
    if override:
        return Path(override)
    appdata = os.environ.get("APPDATA")
    root = Path(appdata) if appdata else Path.home() / ".config"
    return root / "SpectrumPlatform" / "pv_mapping.json"


# 条目数骤减的保护阈值：新配置少于「现有条目的一半」、且现有条目不少于 10 时，
# 认定这是"把残缺的表存了回来"（客户端只渲染了一部分、脚本传错了文件……），
# 必须显式带 confirm_shrink=true 才接受。
# 为什么服务端也要拦：映射决定"谁能写、写到多少"，存坏了整台机器的控制都会失灵，
# 而**任何客户端**（含脚本、测试）都能调这个接口。实测踩过：一个测试用例忘了把
# 网络请求换成桩，直接把 128 条映射存成了 3 条测试数据（2026-09-16）。
SHRINK_GUARD_MIN_ENTRIES = 10
SHRINK_GUARD_RATIO = 0.5


def shrink_warning(current: int, proposed: int) -> str | None:
    """条目数骤减时给出一句可展示的原因；正常收缩返回 ``None``。"""
    if current < SHRINK_GUARD_MIN_ENTRIES:
        return None
    if proposed >= current * SHRINK_GUARD_RATIO:
        return None
    return (
        f"新映射只有 {proposed} 条，而当前有 {current} 条（不足一半）。"
        "这通常意味着把残缺的一份表存了回来（界面只显示了一部分、或脚本传错了文件），"
        "存下去会让没列出的设备全部失去映射。"
        "确实要这样改，请显式带 confirm_shrink=true 再提交。"
    )


def load_config() -> PvMappingConfig:
    """读取配置；文件不存在、损坏或没有可用条目时回退默认值（不抛异常，保证服务可启动）。

    空条目清单也算不可用：设备服务没有任何 PV 时健康检查会报
    「ready / 0 项」，那是个误导性的状态，不如回退到默认映射（与损坏文件同等对待）。
    """
    path = config_path()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default_config()
    except (OSError, json.JSONDecodeError):
        return default_config()
    try:
        config = PvMappingConfig.model_validate(raw)
    except Exception:  # noqa: BLE001  历史/手改坏文件一律回退默认值
        return default_config()
    if not config.entries:
        return default_config()
    return config


class PvMappingLoadError(RuntimeError):
    """现场映射存在但不可用；运行时必须进入只读保护，不能静默换默认 PV。"""


def load_config_checked() -> PvMappingConfig:
    """生产运行时使用的失效关闭加载器；仅首次安装时允许使用默认映射。"""
    path = config_path()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        config = PvMappingConfig.model_validate(raw)
    except FileNotFoundError:
        return default_config()
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise PvMappingLoadError(f"PV 映射读取失败：{path}（{exc}）") from exc
    # 新增能力字段对老现场文件做一次内存迁移：只按同名内置设备补缺失键，
    # 已经显式写过 true/false 的现场选择绝不覆盖。
    defaults = {entry.signal: entry for entry in default_config().entries}
    raw_entries = {
        str(item.get("signal") or ""): item
        for item in raw.get("entries", [])
        if isinstance(item, dict)
    }
    migrated = []
    for entry in config.entries:
        source = raw_entries.get(entry.signal, {})
        fallback = defaults.get(entry.signal)
        updates = {}
        if fallback is not None:
            for field in (
                "device_id",
                "device_label",
                "scan_axis",
                "scan_detector",
                "safe_value",
                # 调束用途标记：老现场文件没有这两个键时按设备档案规则补齐。
                # 缺 beam_target 的直接后果是调束页"优化目标"下拉为空；
                # 缺 tunable 则"优化变量"只剩少数几条（2026-09-20 现场）。
                "tunable",
                "beam_target",
            ):
                missing = field not in source
                if field in {"device_id", "device_label"}:
                    missing = not str(source.get(field) or "").strip()
                if missing:
                    updates[field] = getattr(fallback, field)
        migrated.append(entry.model_copy(update=updates) if updates else entry)
    config = config.model_copy(update={"entries": migrated})
    issues = validate_config(config)
    if issues:
        detail = "；".join(issue.message for issue in issues[:3])
        raise PvMappingLoadError(f"PV 映射校验失败：{path}（{detail}）")
    return config


def save_config(config: PvMappingConfig) -> Path:
    """原子写盘：先写同目录临时文件再替换，避免中途失败留下半截配置。"""
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(config.model_dump(), ensure_ascii=False, indent=2) + "\n"
    if path.exists():
        try:
            previous = PvMappingConfig.model_validate(
                json.loads(path.read_text(encoding="utf-8"))
            )
        except (OSError, json.JSONDecodeError, ValueError):
            previous = None
        if previous is not None and not validate_config(previous):
            shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    handle, temp_name = tempfile.mkstemp(
        dir=str(path.parent), prefix=".pv_mapping-", suffix=".tmp"
    )
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except BaseException:
        Path(temp_name).unlink(missing_ok=True)
        raise
    return path


def validate_config(config: PvMappingConfig) -> list[PvMappingIssue]:
    """逐行校验，返回全部问题（不是遇到第一个就返回），供界面逐行标红。

    index 为 entries 行号，-1 表示整体配置问题。
    """
    issues: list[PvMappingIssue] = []

    if not config.entries:
        issues.append(
            PvMappingIssue(
                index=-1, field="entries", message="至少需要保留一条 PV 映射"
            )
        )

    seen_signals: dict[str, int] = {}
    seen_pvs: dict[str, int] = {}
    by_signal = {entry.signal: entry for entry in config.entries}
    for index, entry in enumerate(config.entries):
        if not _SIGNAL_PATTERN.match(entry.signal):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="signal",
                    message="业务信号需为小写点分形式，如 quadrupole.q1.current",
                )
            )
        elif entry.signal in seen_signals:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="signal",
                    message=f"业务信号与第 {seen_signals[entry.signal] + 1} 行重复",
                )
            )
        else:
            seen_signals[entry.signal] = index

        if not entry.pv:
            issues.append(
                PvMappingIssue(index=index, field="pv", message="PV 名称不能为空")
            )
        elif not _PV_PATTERN.match(entry.pv):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="pv",
                    message="PV 名称含非法字符（不允许空格）",
                )
            )
        elif entry.pv in seen_pvs:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="pv",
                    message=f"PV 名称与第 {seen_pvs[entry.pv] + 1} 行重复",
                )
            )
        else:
            seen_pvs[entry.pv] = index

        if not entry.label.strip():
            issues.append(
                PvMappingIssue(index=index, field="label", message="设备参数名不能为空")
            )

        if entry.role not in ("", *SIGNAL_ROLES):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="role",
                    message=f"未知信号角色：{entry.role}",
                )
            )
        if entry.display_order < 0:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="display_order",
                    message="显示顺序不能为负数",
                )
            )
        if (
            entry.scan_axis
            or entry.scan_detector
            or entry.tunable
            or entry.beam_target
        ) and not entry.group:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="group",
                    message="扫谱/调束能力必须配置设备分组",
                )
            )
        if entry.safe_value is not None:
            if entry.min_value is not None and entry.safe_value < entry.min_value:
                issues.append(
                    PvMappingIssue(index=index, field="safe_value", message="安全值低于下限")
                )
            if entry.max_value is not None and entry.safe_value > entry.max_value:
                issues.append(
                    PvMappingIssue(index=index, field="safe_value", message="安全值超过上限")
                )
        if entry.scan_axis:
            if not entry.writable or entry.role != "setpoint":
                issues.append(
                    PvMappingIssue(
                        index=index,
                        field="scan_axis",
                        message="扫描轴必须是可写 setpoint",
                    )
                )
            if not entry.readback_signal or entry.settle_tol is None:
                issues.append(
                    PvMappingIssue(
                        index=index,
                        field="scan_axis",
                        message="扫描轴必须配置回读信号和稳定容差",
                    )
                )
            if entry.max_step is None or entry.max_step <= 0:
                issues.append(
                    PvMappingIssue(
                        index=index,
                        field="scan_axis",
                        message="扫描轴必须配置正数最大单步",
                    )
                )
        if entry.scan_detector and (entry.writable or entry.role != "readback"):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="scan_detector",
                    message="扫描探测器必须是只读 readback",
                )
            )
        if entry.tunable and (not entry.writable or entry.role != "setpoint"):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="tunable",
                    message="调束变量必须是可写 setpoint",
                )
            )
        if entry.tunable and (entry.max_step is None or entry.max_step <= 0):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="tunable",
                    message="调束变量必须配置正数最大单步",
                )
            )
        if entry.tunable and entry.signal.endswith(".current_rate_setpoint"):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="tunable",
                    message="变化速率属于保护参数，不能作为调束变量",
                )
            )
        if entry.beam_target and (entry.writable or entry.role != "readback"):
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="beam_target",
                    message="调束目标必须是只读 readback",
                )
            )

        if entry.readback_signal and entry.readback_signal not in by_signal:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="readback_signal",
                    message=f"回读信号不在映射里：{entry.readback_signal}",
                )
            )
        elif entry.readback_signal and by_signal[entry.readback_signal].writable:
            issues.append(
                PvMappingIssue(
                    index=index,
                    field="readback_signal",
                    message="回读信号必须是只读测量，不能指向可写设定值",
                )
            )

        # 变化速率配对：配了就必须指向本配置里存在且可写的信号。写错了不会报错，
        # 只会在成组回落时静默不下发速率——那种"看着做了、其实没做"最难查。
        if entry.rate_signal:
            target = by_signal.get(entry.rate_signal)
            if target is None:
                issues.append(
                    PvMappingIssue(
                        index=index,
                        field="rate_signal",
                        message=f"速率信号不在映射里：{entry.rate_signal}",
                    )
                )
            elif not target.writable:
                issues.append(
                    PvMappingIssue(
                        index=index,
                        field="rate_signal",
                        message=f"速率信号不可写：{entry.rate_signal}",
                    )
                )

    return issues


def simulated_seed_values(config: PvMappingConfig) -> dict[str, tuple[float, str]]:
    """把映射翻译成模拟网关需要的 ``{signal: (初值, 单位)}``。

    初值优先取当前设备配置档（团簇源的现场观测值），未覆盖的信号回退 0.0。
    """
    seeds = dict(DEFAULT_SIMULATED_VALUES)
    seeds.update(device_profiles.SIMULATED_VALUES)
    return {
        entry.signal: (seeds.get(entry.signal, 0.0), entry.unit)
        for entry in config.entries
    }
